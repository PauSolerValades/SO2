Colocar el contingut de les carpetes dins de la BAses de dades de gutenberg. Executar com el makefile normal, no hauria d'haver-hi més problemes, em sap greu per les inconvenciències.
