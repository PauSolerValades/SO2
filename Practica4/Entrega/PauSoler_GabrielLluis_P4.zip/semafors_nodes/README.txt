El makefile ha estat modificat per acceptar altres fills.
Per implementar semafors per cada node hem hagut de modificat l'struct node_data i tree-to-mmap.c, per això adjuntem aquestes dues classes. Si falta algun fitxer contacteu-nos, per favor.
