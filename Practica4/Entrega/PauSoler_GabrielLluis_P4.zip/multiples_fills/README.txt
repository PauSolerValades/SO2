El makefile està modificat per poder-se adaptar als múltiples processos.
No fa falta cap altre fitxer (en cas de que m'equivoqui contacteu amb nosaltres per favor)
