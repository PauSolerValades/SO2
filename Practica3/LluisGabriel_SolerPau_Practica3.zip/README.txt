TO EXECUTE THE CODE:
1. Makefile has not been changed from last delivery, but we included it anyway
2. red_black_tree.c and red_black_tree.h have been modified, so we included it as well.
3. To search the most common word we call a bash command from our C code. This implies that this delivery is going to word ONLY ON LINUX (at least this point), and we haven't contempled it any other way.
4. Is assumed that this program is exetucted within the Gutenberd data base, not outside.

