A tenir en compte:
- Presentem dues versions del main, però l'arxiu Makefile està fet perquè compili
el main2, que és en el que els fils secundaris tenen còpies reals de l'arbre del
fil principal.
- Si es vol compilar amb l'altre main, només cal canviar en el Makefile on posa
main2.c per main.c